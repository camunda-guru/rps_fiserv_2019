 print("hello");

print(context.getVariable("jwt-token"));
print( context.getVariable("myname"));
var data = context.getVariable("myname");
context.setVariable("private.key",data);
context.setVariable("request.header.jwt-token",context.getVariable("jwt-token"));