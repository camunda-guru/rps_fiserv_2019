print("Inside javascript .....");

var data=context.getVariable("organizationName");

print(data);