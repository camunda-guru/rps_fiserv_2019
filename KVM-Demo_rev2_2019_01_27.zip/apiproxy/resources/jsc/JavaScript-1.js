 if(request.queryParams['myname']){
     print("entered");
	print(request.queryParams['myname'][0]); 
	context.setVariable("private.key",request.queryParams['myname'][0]);
 
 }
 else
  print("No");